export const profile = {
  name: 'Ratna Kumar Pattanaik',
  title: 'Cybersecurity Enthusiast | CSE Student',
  intro:
    'Passionate about cybersecurity, ethical hacking, Python programming, Linux, and emerging technologies. I enjoy building projects and solving real-world problems through technology.',
  email: 'ratna.pattanaik@example.com',
  github: 'https://github.com/ratnakumarpattanaik',
  githubUser: 'ratnakumarpattanaik',
  linkedin: 'https://linkedin.com/in/ratna-kumar-pattanaik-34423837b',
  resume: '/resume.pdf',
}

export const typedRoles = [
  'Cybersecurity Enthusiast',
  'Ethical Hacking Learner',
  'Python Developer',
  'Linux User',
  'CSE Student',
]

export const skills = [
  { name: 'Python', level: 40 },
  { name: 'SQL', level: 35 },
  { name: 'Git & GitHub', level: 10 },
  { name: 'Networking', level: 74 },
  { name: 'Cybersecurity Fundamentals', level: 30 },
]

export const projects = [
  {
    title: 'Password Strength Checker',
    description:
      'A tool that analyzes password strength in real time using entropy scoring, pattern detection, and breach heuristics to help users create stronger credentials.',
    tags: ['Python', 'Security', 'CLI'],
    repo: 'https://github.com/ratnakumarpattanaik',
  },
  {
    title: 'CyberSecurity Toolkit',
    description:
      'A modular collection of security utilities including port scanning, hash generation, and basic vulnerability checks, packaged for quick reconnaissance and learning.',
    tags: ['Python', 'Networking', 'Recon'],
    repo: 'https://github.com/ratnakumarpattanaik',
  },
]

export const certifications = [
  {
    title: 'Cyber Security — Live Training',
    issuer: 'ExcelR EdTech',
    description:
      '30-hour live training program on Cyber Security completed from January 12 to February 3, 2026. Certificate No. 129877.',
    file: '/certificates/cybersecurity-excelr.pdf',
  },
  {
    title: 'Docker Workshop',
    issuer: 'Club Excel — NIST University',
    description:
      'Hands-on workshop on Docker and containerization organized by Club Excel on February 25–26, 2026 at NIST University, Berhampur.',
    file: '/certificates/docker-workshop.pdf',
  },
  {
    title: 'Game Development Workshop',
    issuer: 'Club Multimedia — NIST University',
    description:
      'Participation in the Game Development Workshop organized by Club Multimedia on March 23–24, 2026, including workshop activities and project submission.',
    file: '/certificates/game-dev-workshop.png',
  },
]

export const education = [
  {
    degree: 'B.Tech in Computer Science & Engineering',
    school: 'NIST University',
    period: 'Present',
    detail:
      'Focusing on cybersecurity, networking, and software development while building practical projects.',
  },
  {
    degree: 'Higher Secondary Education',
    school: 'Senior Secondary (12th)',
    period: 'Completed',
    detail: 'Science stream with mathematics and computer science fundamentals.',
  },
  {
    degree: 'Secondary Education',
    school: 'Secondary School (10th)',
    period: 'Completed',
    detail: 'Built the academic foundation that sparked an interest in technology.',
  },
]

export const githubStats = [
  { label: 'Public Repositories', value: '20+' },
  { label: 'Contributions / Year', value: '450+' },
  { label: 'Languages Used', value: '6' },
  { label: 'Longest Streak', value: '30 days' },
]

export const featuredRepos = [
  {
    name: 'cybersecurity-toolkit',
    description: 'Modular security utilities for recon and learning.',
    language: 'Python',
    stars: 24,
  },
  {
    name: 'password-strength-checker',
    description: 'Real-time password strength analysis tool.',
    language: 'Python',
    stars: 18,
  },
  {
    name: 'linux-notes',
    description: 'Curated notes and scripts for Linux administration.',
    language: 'Shell',
    stars: 12,
  },
]
