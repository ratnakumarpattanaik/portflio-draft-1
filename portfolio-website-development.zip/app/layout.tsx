import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { JetBrains_Mono } from 'next/font/google'
import './globals.css'

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Ratna Kumar Pattanaik | Cybersecurity Enthusiast & CSE Student',
  description:
    'Portfolio of Ratna Kumar Pattanaik, a B.Tech Computer Science & Engineering student at NIST University passionate about cybersecurity, ethical hacking, Python, Linux, and emerging technologies.',
  generator: 'v0.app',
  keywords: [
    'Ratna Kumar Pattanaik',
    'Cybersecurity',
    'Ethical Hacking',
    'CSE Student',
    'NIST University',
    'Python',
    'Linux',
    'Portfolio',
  ],
  authors: [{ name: 'Ratna Kumar Pattanaik' }],
  openGraph: {
    title: 'Ratna Kumar Pattanaik | Cybersecurity Enthusiast & CSE Student',
    description:
      'Passionate about cybersecurity, ethical hacking, Python, Linux, and emerging technologies.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0a0a0a',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`dark ${jetbrainsMono.variable}`}>
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
