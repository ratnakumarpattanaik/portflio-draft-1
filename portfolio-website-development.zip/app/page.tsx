import { About } from '@/components/about'
import { Certifications } from '@/components/certifications'
import { Contact } from '@/components/contact'
import { Education } from '@/components/education'
import { GitHubSection } from '@/components/github-section'
import { Hero } from '@/components/hero'
import { Navbar } from '@/components/navbar'
import { ParticlesBackground } from '@/components/particles-background'
import { Projects } from '@/components/projects'
import { Skills } from '@/components/skills'

export default function Page() {
  return (
    <main className="relative min-h-screen bg-[#0A0A0A] text-white">
      <ParticlesBackground />
      <Navbar />
      <Hero />
      <About />
      <Skills />
      <Projects />
      <Certifications />
      <Education />
      <GitHubSection />
      <Contact />
    </main>
  )
}
