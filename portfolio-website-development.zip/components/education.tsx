'use client'

import { motion } from 'framer-motion'
import { GraduationCap } from 'lucide-react'
import { education } from '@/lib/data'
import { SectionHeading } from './section-heading'

export function Education() {
  return (
    <section id="education" className="relative py-24">
      <div className="mx-auto max-w-4xl px-6">
        <SectionHeading index="05" title="Education" />

        <div className="relative border-l border-[#FF0000]/25 pl-8">
          {education.map((item, i) => (
            <motion.div
              key={item.degree}
              initial={{ opacity: 0, x: 24 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.45, delay: i * 0.1 }}
              className="relative mb-10 last:mb-0"
            >
              <span className="absolute -left-[41px] flex h-5 w-5 items-center justify-center rounded-full border border-[#FF0000] bg-[#0A0A0A] shadow-[0_0_12px_rgba(255,0,0,0.7)]">
                <span className="h-2 w-2 rounded-full bg-[#FF0000]" />
              </span>
              <div className="glass box-glow-hover rounded-xl border border-[#FF0000]/20 p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <GraduationCap
                      className="h-5 w-5 shrink-0 text-[#FF0000]"
                      aria-hidden="true"
                    />
                    <h3 className="font-semibold text-white">{item.degree}</h3>
                  </div>
                  <span className="shrink-0 font-mono text-xs text-[#FF0000]">
                    {item.period}
                  </span>
                </div>
                <p className="mt-2 text-sm text-white/80">{item.school}</p>
                <p className="mt-2 text-sm text-[#A0A0A0]">{item.detail}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
