'use client'

import { useMemo } from 'react'
import { motion } from 'framer-motion'
import { Star } from 'lucide-react'
import { featuredRepos, githubStats, profile } from '@/lib/data'
import { GithubIcon } from './brand-icons'
import { SectionHeading } from './section-heading'

const WEEKS = 52
const DAYS = 7

function useContributionGrid() {
  return useMemo(() => {
    const cells: number[] = []
    for (let i = 0; i < WEEKS * DAYS; i++) {
      const seed = Math.sin(i * 12.9898) * 43758.5453
      const rand = seed - Math.floor(seed)
      cells.push(Math.floor(rand * 5))
    }
    return cells
  }, [])
}

const levelColor = [
  'bg-[#1a1a1a]',
  'bg-[#4d0000]',
  'bg-[#800000]',
  'bg-[#cc0000]',
  'bg-[#ff0000]',
]

export function GitHubSection() {
  const grid = useContributionGrid()

  return (
    <section id="github" className="relative py-24">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[#121212]/40" />
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          index="06"
          title="GitHub"
          subtitle="Contributions, activity, and featured repositories."
        />

        <div className="mb-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {githubStats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="glass box-glow rounded-xl border border-[#FF0000]/20 p-5 text-center"
            >
              <p className="text-2xl font-bold text-[#FF0000] text-glow">
                {stat.value}
              </p>
              <p className="mt-1 text-xs text-[#A0A0A0]">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-60px' }}
          transition={{ duration: 0.5 }}
          className="glass box-glow mb-8 overflow-hidden rounded-xl border border-[#FF0000]/20 p-6"
        >
          <div className="mb-4 flex items-center gap-2">
            <GithubIcon className="h-5 w-5 text-[#FF0000]" />
            <span className="font-mono text-sm text-white">
              Contribution activity
            </span>
          </div>
          <div className="overflow-x-auto">
            <div
              className="grid grid-flow-col gap-[3px]"
              style={{ gridTemplateRows: `repeat(${DAYS}, minmax(0, 1fr))` }}
              role="img"
              aria-label="GitHub contribution graph showing a year of activity"
            >
              {grid.map((level, i) => (
                <span
                  key={i}
                  className={`h-[10px] w-[10px] rounded-[2px] ${levelColor[level]}`}
                />
              ))}
            </div>
          </div>
          <div className="mt-4 flex items-center justify-end gap-2 text-xs text-[#A0A0A0]">
            <span>Less</span>
            {levelColor.map((c, i) => (
              <span key={i} className={`h-[10px] w-[10px] rounded-[2px] ${c}`} />
            ))}
            <span>More</span>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {featuredRepos.map((repo, i) => (
            <motion.a
              key={repo.name}
              href={profile.github}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              className="glass box-glow-hover group rounded-xl border border-[#FF0000]/20 p-5"
            >
              <div className="flex items-center gap-2">
                <GithubIcon className="h-4 w-4 text-[#FF0000]" />
                <span className="font-mono text-sm text-white transition-colors group-hover:text-[#FF0000]">
                  {repo.name}
                </span>
              </div>
              <p className="mt-3 text-sm text-[#A0A0A0]">{repo.description}</p>
              <div className="mt-4 flex items-center gap-4 text-xs text-[#A0A0A0]">
                <span className="flex items-center gap-1">
                  <span className="h-3 w-3 rounded-full bg-[#FF0000]" />
                  {repo.language}
                </span>
                <span className="flex items-center gap-1">
                  <Star className="h-3 w-3" aria-hidden="true" />
                  {repo.stars}
                </span>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  )
}
