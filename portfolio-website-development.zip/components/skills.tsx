'use client'

import { motion } from 'framer-motion'
import { skills } from '@/lib/data'
import { SectionHeading } from './section-heading'

export function Skills() {
  return (
    <section id="skills" className="relative py-24">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[#121212]/40" />
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          index="02"
          title="Skills"
          subtitle="Tools and technologies I work with across security, development, and systems."
        />

        <div className="grid grid-cols-1 gap-x-10 gap-y-6 sm:grid-cols-2">
          {skills.map((skill, i) => (
            <motion.div
              key={skill.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
            >
              <div className="mb-2 flex items-center justify-between">
                <span className="font-mono text-sm text-white">
                  {skill.name}
                </span>
                <span className="font-mono text-xs text-[#FF0000]">
                  {skill.level}%
                </span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-[#1e1e1e]">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.level}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.9, delay: i * 0.05, ease: 'easeOut' }}
                  className="h-full rounded-full bg-gradient-to-r from-[#CC0000] to-[#FF0000] shadow-[0_0_12px_rgba(255,0,0,0.7)]"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
