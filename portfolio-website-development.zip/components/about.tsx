'use client'

import { motion } from 'framer-motion'
import { GraduationCap, Lightbulb, ShieldCheck, Terminal } from 'lucide-react'
import { SectionHeading } from './section-heading'

const highlights = [
  {
    icon: GraduationCap,
    title: 'CSE Student',
    text: 'B.Tech Computer Science & Engineering at NIST University.',
  },
  {
    icon: ShieldCheck,
    title: 'Security Focused',
    text: 'Cybersecurity, networking, and ethical hacking fundamentals.',
  },
  {
    icon: Terminal,
    title: 'Builder',
    text: 'Python, Linux, and hands-on projects that solve real problems.',
  },
  {
    icon: Lightbulb,
    title: 'Curious',
    text: 'Driven by continuous learning and emerging technology.',
  },
]

export function About() {
  return (
    <section id="about" className="relative py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading index="01" title="About Me" />

        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.5 }}
            className="glass box-glow rounded-xl border border-[#FF0000]/20 p-8"
          >
            <p className="font-mono text-sm text-[#FF0000]">$ cat about.txt</p>
            <p className="mt-4 leading-relaxed text-[#A0A0A0]">
              I&apos;m a B.Tech Computer Science &amp; Engineering student at{' '}
              <span className="text-white">NIST University</span>, deeply
              interested in{' '}
              <span className="text-white">
                cybersecurity, Python, Linux, networking, and ethical hacking
              </span>
              .
            </p>
            <p className="mt-4 leading-relaxed text-[#A0A0A0]">
              I&apos;m passionate about learning and innovation, constantly
              exploring how systems work and how to secure them. I love turning
              ideas into working projects and improving my skills through
              real-world challenges.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {highlights.map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 0.45, delay: i * 0.08 }}
                className="glass box-glow-hover rounded-xl border border-[#FF0000]/15 p-6"
              >
                <item.icon
                  className="h-7 w-7 text-[#FF0000]"
                  aria-hidden="true"
                />
                <h3 className="mt-4 font-semibold text-white">{item.title}</h3>
                <p className="mt-2 text-sm text-[#A0A0A0]">{item.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
