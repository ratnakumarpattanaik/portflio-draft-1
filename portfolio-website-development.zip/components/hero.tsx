'use client'

import { useEffect, useState } from 'react'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { Download, Mail } from 'lucide-react'
import { profile, typedRoles } from '@/lib/data'

function useTypewriter(words: string[]) {
  const [text, setText] = useState('')
  const [wordIndex, setWordIndex] = useState(0)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    const current = words[wordIndex % words.length]
    const speed = deleting ? 45 : 90

    const timeout = setTimeout(() => {
      const next = deleting
        ? current.slice(0, text.length - 1)
        : current.slice(0, text.length + 1)
      setText(next)

      if (!deleting && next === current) {
        setTimeout(() => setDeleting(true), 1400)
      } else if (deleting && next === '') {
        setDeleting(false)
        setWordIndex((i) => i + 1)
      }
    }, speed)

    return () => clearTimeout(timeout)
  }, [text, deleting, wordIndex, words])

  return text
}

export function Hero() {
  const typed = useTypewriter(typedRoles)

  return (
    <section
      id="hero"
      className="relative flex min-h-screen items-center overflow-hidden pt-24"
    >
      <div className="grid-bg pointer-events-none absolute inset-0 -z-10 opacity-40" />
      <div className="pointer-events-none absolute left-1/2 top-1/3 -z-10 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-[#FF0000]/15 blur-[120px]" />

      <div className="mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-12 px-6 md:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <p className="font-mono text-sm tracking-widest text-[#FF0000]">
            &gt; whoami
          </p>
          <h1 className="mt-4 text-4xl font-bold leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
            {profile.name}
          </h1>
          <p className="mt-4 h-8 font-mono text-lg text-[#A0A0A0] sm:text-xl">
            <span className="text-white caret">{typed}</span>
          </p>
          <p className="mt-6 max-w-xl text-pretty leading-relaxed text-[#A0A0A0]">
            {profile.intro}
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <a
              href={profile.resume}
              download
              className="box-glow-hover inline-flex items-center gap-2 rounded-md bg-[#FF0000] px-6 py-3 font-mono text-sm font-semibold text-white shadow-[0_0_24px_-4px_rgba(255,0,0,0.7)] transition hover:bg-[#CC0000]"
            >
              <Download className="h-4 w-4" aria-hidden="true" />
              Download Resume
            </a>
            <a
              href="#contact"
              className="box-glow-hover inline-flex items-center gap-2 rounded-md border border-[#FF0000]/50 px-6 py-3 font-mono text-sm font-semibold text-white transition hover:border-[#FF0000]"
            >
              <Mail className="h-4 w-4" aria-hidden="true" />
              Contact Me
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="flex justify-center md:justify-end"
        >
          <div className="relative">
            <div className="absolute -inset-2 rounded-full bg-gradient-to-tr from-[#FF0000] via-[#CC0000] to-transparent opacity-70 blur-md" />
            <div className="absolute -inset-4 animate-pulse rounded-full border border-[#FF0000]/30" />
            <div className="relative h-56 w-56 overflow-hidden rounded-full border-2 border-[#FF0000]/60 sm:h-72 sm:w-72">
              <Image
                src="/profile.png"
                alt="Portrait of Ratna Kumar Pattanaik"
                fill
                sizes="(max-width: 640px) 224px, 288px"
                className="object-cover"
                priority
              />
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
