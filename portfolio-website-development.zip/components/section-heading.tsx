'use client'

import { motion } from 'framer-motion'

interface SectionHeadingProps {
  index: string
  title: string
  subtitle?: string
}

export function SectionHeading({ index, title, subtitle }: SectionHeadingProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-80px' }}
      transition={{ duration: 0.5 }}
      className="mb-12 flex flex-col items-center text-center"
    >
      <span className="font-mono text-sm tracking-widest text-[#FF0000]">
        {index} //
      </span>
      <h2 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-4xl">
        {title}
      </h2>
      <div className="mt-4 h-px w-24 bg-gradient-to-r from-transparent via-[#FF0000] to-transparent" />
      {subtitle ? (
        <p className="mt-4 max-w-2xl text-balance text-[#A0A0A0]">{subtitle}</p>
      ) : null}
    </motion.div>
  )
}
