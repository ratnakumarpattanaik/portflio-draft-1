'use client'

import { motion } from 'framer-motion'
import { Mail } from 'lucide-react'
import { GithubIcon, LinkedinIcon } from './brand-icons'
import { profile } from '@/lib/data'
import { SectionHeading } from './section-heading'

const channels = [
  {
    icon: Mail,
    label: 'Email',
    value: profile.email,
    href: `mailto:${profile.email}`,
  },
  {
    icon: LinkedinIcon,
    label: 'LinkedIn',
    value: '/ratnakumarpattanaik',
    href: profile.linkedin,
  },
  {
    icon: GithubIcon,
    label: 'GitHub',
    value: `/${profile.githubUser}`,
    href: profile.github,
  },
]

export function Contact() {
  return (
    <section id="contact" className="relative py-24">
      <div className="pointer-events-none absolute left-1/2 top-1/2 -z-10 h-[300px] w-[300px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#FF0000]/10 blur-[120px]" />
      <div className="mx-auto max-w-4xl px-6">
        <SectionHeading
          index="07"
          title="Contact"
          subtitle="Open to internships and cybersecurity opportunities. Let's connect."
        />

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {channels.map((c, i) => (
            <motion.a
              key={c.label}
              href={c.href}
              target={c.href.startsWith('http') ? '_blank' : undefined}
              rel={c.href.startsWith('http') ? 'noopener noreferrer' : undefined}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              className="glass box-glow-hover group flex flex-col items-center rounded-xl border border-[#FF0000]/20 p-6 text-center"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full border border-[#FF0000]/40 bg-[#FF0000]/10 transition-colors group-hover:bg-[#FF0000]/20">
                <c.icon className="h-5 w-5 text-[#FF0000]" aria-hidden="true" />
              </div>
              <p className="mt-4 font-mono text-sm text-white">{c.label}</p>
              <p className="mt-1 break-all text-xs text-[#A0A0A0]">{c.value}</p>
            </motion.a>
          ))}
        </div>
      </div>

      <footer className="mt-20 border-t border-[#FF0000]/15 pt-8">
        <p className="text-center font-mono text-xs text-[#A0A0A0]">
          <span className="text-[#FF0000]">&copy; {new Date().getFullYear()}</span>{' '}
          Ratna Kumar Pattanaik &mdash; Built with security in mind.
        </p>
      </footer>
    </section>
  )
}
