'use client'

import { motion } from 'framer-motion'
import { ArrowUpRight, FolderGit2 } from 'lucide-react'
import { projects } from '@/lib/data'
import { SectionHeading } from './section-heading'

export function Projects() {
  return (
    <section id="projects" className="relative py-24">
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          index="03"
          title="Projects"
          subtitle="A selection of things I've built while learning and experimenting."
        />

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {projects.map((project, i) => (
            <motion.a
              key={project.title}
              href={project.repo}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.45, delay: i * 0.1 }}
              className="glass box-glow-hover group flex flex-col rounded-xl border border-[#FF0000]/20 p-6"
            >
              <div className="flex items-center justify-between">
                <FolderGit2
                  className="h-8 w-8 text-[#FF0000]"
                  aria-hidden="true"
                />
                <ArrowUpRight
                  className="h-5 w-5 text-[#A0A0A0] transition-colors group-hover:text-[#FF0000]"
                  aria-hidden="true"
                />
              </div>
              <h3 className="mt-5 text-lg font-semibold text-white transition-colors group-hover:text-[#FF0000]">
                {project.title}
              </h3>
              <p className="mt-3 flex-1 text-sm leading-relaxed text-[#A0A0A0]">
                {project.description}
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full border border-[#FF0000]/30 bg-[#FF0000]/5 px-3 py-1 font-mono text-xs text-[#FF0000]"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  )
}
