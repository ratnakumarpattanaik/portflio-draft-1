'use client'

import { motion } from 'framer-motion'
import { Award, ExternalLink } from 'lucide-react'
import { certifications } from '@/lib/data'
import { SectionHeading } from './section-heading'

export function Certifications() {
  return (
    <section id="certifications" className="relative py-24">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[#121212]/40" />
      <div className="mx-auto max-w-6xl px-6">
        <SectionHeading
          index="04"
          title="Certifications"
          subtitle="Credentials earned through courses, workshops, and technical training."
        />

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {certifications.map((cert, i) => (
            <motion.a
              key={cert.title}
              href={cert.file}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`View ${cert.title} certificate (opens in a new tab)`}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.45, delay: i * 0.1 }}
              className="glass box-glow-hover group block rounded-xl border border-[#FF0000]/20 p-6"
            >
              <div className="flex items-center justify-between">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg border border-[#FF0000]/30 bg-[#FF0000]/10">
                  <Award className="h-6 w-6 text-[#FF0000]" aria-hidden="true" />
                </div>
                <ExternalLink
                  className="h-4 w-4 text-[#A0A0A0] transition-colors group-hover:text-[#FF0000]"
                  aria-hidden="true"
                />
              </div>
              <h3 className="mt-5 text-lg font-semibold text-white">
                {cert.title}
              </h3>
              <p className="mt-1 font-mono text-xs text-[#FF0000]">
                {cert.issuer}
              </p>
              <p className="mt-3 text-sm leading-relaxed text-[#A0A0A0]">
                {cert.description}
              </p>
              <span className="mt-4 inline-flex items-center gap-1.5 font-mono text-xs text-[#FF0000] opacity-0 transition-opacity group-hover:opacity-100">
                View certificate
              </span>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  )
}
